# picoCTF
My write-up for different levels in picoCTF
The levels i have completed: 

|Sr No.|Reverse Engineering|Binary Exploitation|Web Exploitation|Forensics|Cryptography|
|------|------------------|-------------------|----------------|---------|------------|
|  1   |Keygenme-py|stonks |cass|Macrohard Weakedge|new caesar|
|2|ARMssembly 0|buffer overflow 0|Forbidden paths|tunn3l_v1s10n|miniRSA|
|3|-|-|Local Authority|-|mod1/mod2|
